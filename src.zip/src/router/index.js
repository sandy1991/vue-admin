import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [
    { path: '/login', name:'login',component: () => import('@/views/login/index'), hidden: true },
    {
      path: '/',
      name:'home',
      component: () => import('@/views/home/index'),
      redirect: { name: 'dashBoard' },
      children:[
        {
          path:'/dashBoard',
          name:'dashBoard',
          component: () => import('@/views/home/dashBoard'),
        },{
          path:'/User',
          component: () => import('@/views/user/index'),
        }
      ],
      beforeEnter (to, from, next) {
        let token = Vue.cookie.get('token')
        if (!token || !/\S/.test(token)) {
          next({ name: 'login' })
        }
        next()
      }
    }
  ]
})
