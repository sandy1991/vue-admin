<template>
  <aside class="asidebar">
  <el-aside :width="$store.state.sidebarCollapse? '65px' : '200px'" style="background-color: #545c64">
                <el-menu class="el-menu-vertical-demo" unique-opened router :collapse="$store.state.sidebarCollapse"
                     background-color="#545c64"
                    text-color="#fff"
                    active-text-color="#ffd04b"
                >
                     <el-submenu index="1">
                        <template slot="title">
                            <i class="el-icon-location"></i>
                            <span>系统管理</span>
                        </template>
                        <el-menu-item index="User">用户管理</el-menu-item>
                        <el-menu-item index="1-2">资源管理</el-menu-item>
                        <el-menu-item index="1-3">角色管理</el-menu-item>
                        <el-menu-item index="1-3">字典管理</el-menu-item>
                        <el-menu-item index="1-3">区域信息管理</el-menu-item>
                        <el-submenu index="1-4">
                            <template slot="title">选项4</template>
                            <el-menu-item index="1-4-1">选项1</el-menu-item>
                        </el-submenu>
                    </el-submenu>
                    <el-menu-item index="3">
                        <i class="el-icon-menu"></i>
                        <span slot="title">导航二</span>
                    </el-menu-item>
                    <el-menu-item index="4" disabled>
                        <i class="el-icon-document"></i>
                        <span slot="title">导航三</span>
                    </el-menu-item>
                    <el-menu-item index="5">
                        <i class="el-icon-setting"></i>
                        <span slot="title">导航四</span>
                    </el-menu-item>
                    </el-menu>
            </el-aside>
    </aside>
</template>
<script>
export default {
   data() {
            return {
                isCollapse: false
            };
        },
}
</script>

<style scoped="scoped">
  .asidebar {
    background-color: #D3DCE6;
    color: #333;
    text-align: center;
    border-right: solid 1px #d2d6de; 
    top: 60px;
    position: fixed;
    left: 0;
    bottom: 0;
    height: 100%;
    overflow:hidden;
  }
  .el-aside{
    position: relative;
    z-index: 1;
    height: 100%;
    padding-bottom: 60px;
    overflow-y: auto;
  }
  .el-menu {
        border-right: 0px;
    }
</style>
