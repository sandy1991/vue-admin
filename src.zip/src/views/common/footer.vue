<template>
  <footer class="main-footer">
          <!-- To the right -->
          <div class="footer-version">
                版本号: V1.0
          </div>
          <!-- Default to the left -->
          <strong>Copyright &copy; 2017 <a href="http://www.cnkrt.com/" target="_blank" class="info-url">科睿特软件股份有限公司</a>.</strong> All rights reserved.
    </footer>
</template>

<style scoped="scoped">
  .sidebar--collapse .main-footer{
        margin-left: 64px;
   }
  .main-footer{
    height: 40px;
    line-height: 40px;
    background: #fff;
    padding: 5px 15px;
    color: #444;
    border-top: 1px solid #d2d6de;
    margin-left: 200px;
  }
  .footer-version{
      float: right;
  }
  .info-url {
        color: #409eff;
        text-decoration: none;
    }
</style>
