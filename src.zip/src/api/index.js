/**
 * 接口汇总
 */
import * as common from './modules/common'
import * as user from './modules/user'

export default {
  common,     // 公共接口
  user,       // 用户接口
}
